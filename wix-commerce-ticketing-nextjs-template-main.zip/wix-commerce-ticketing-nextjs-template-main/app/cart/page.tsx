import { CartView } from '@app/components/Cart/CartView';

export default async function CartPage() {
  return <CartView layout="full" />;
}
