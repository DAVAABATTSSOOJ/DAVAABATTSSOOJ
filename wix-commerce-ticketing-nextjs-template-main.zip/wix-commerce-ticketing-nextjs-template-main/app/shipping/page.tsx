import ShippingAndReturns from '@app/components/ShippingAndReturns/ShippingAndReturns';

export default function ShippingPage() {
  return <ShippingAndReturns />;
}
