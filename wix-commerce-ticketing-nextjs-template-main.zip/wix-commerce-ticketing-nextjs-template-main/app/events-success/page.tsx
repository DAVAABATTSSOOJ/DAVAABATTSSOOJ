export default function Success() {
  return (
    <div className="flex flex-col items-center justify-center w-full h-full">
      <h1 className="mt-10">Thank you for your purchase!</h1>
    </div>
  );
}
