export const WIX_SERVICE_FEE = 2.5;

export const WIX_ACCESS_TOKEN = 'wix_accessToken';
export const WIX_REFRESH_TOKEN = 'wix_refreshToken';

export const PLACEHOLDER_IMAGE = '/images/placeholder.jpg';

export const STORES_APP_ID = '1380b703-ce81-ff05-f115-39571d94dfcd';
